Extract *.dll files and QtBitcoinTrader.exe to one folder
